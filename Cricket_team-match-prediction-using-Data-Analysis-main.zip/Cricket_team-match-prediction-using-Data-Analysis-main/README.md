# Cricket_team-match-prediction-using-Data-Analysis
This project analyses various ODI and IPL matches. Match predictions are made using various Data science algorithms

## How to run the code

```bash
git clone https://github.com/codophobia/Cricket-Score-Prediction-Data-Generator.git
virtualenv -p python3 venv # You should have Python3 installed on your system
pip install -r requirements.txt
python script.py
```
